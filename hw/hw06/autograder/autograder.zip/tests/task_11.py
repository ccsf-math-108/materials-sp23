OK_FORMAT = True

test = {   'name': 'task_11',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> 0 <= first_three_black <= 1\nTrue',
                                       'failure_message': '❌ first_three_black should be a numerical value between 0 and 1, inclusive.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ first_three_black is a numerical value between 0 and 1, inclusive.'},
                                   {'code': '>>> \n>>> np.isclose(first_three_black, (18 / 38) ** 3)\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

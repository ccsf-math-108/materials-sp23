OK_FORMAT = True

test = {   'name': 'task_04',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> net_gain_red(10000) != net_gain_red(10000)\nTrue',
                                       'failure_message': '❌ There is essentially no chance that the net gain for 2 rounds of 10,000 bets should the same.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ There is essentially no chance that the net gain for 2 rounds of 10,000 bets should the same.'},
                                   {'code': '>>> \n>>> -10000 <= net_gain_red(10000) <= 10000\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

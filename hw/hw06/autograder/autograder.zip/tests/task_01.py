OK_FORMAT = True

test = {   'name': 'task_01',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> dollar_bet_on_red('red') == 1\nTrue",
                                       'failure_message': "❌ Your function should return 1 when it is called on 'red'.",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': "✅ Your function correctly returns 1 when it is called on 'red'."},
                                   {'code': ">>> \n>>> dollar_bet_on_red('black') == -1\nTrue", 'hidden': True, 'locked': False, 'points': 1},
                                   {'code': ">>> \n>>> dollar_bet_on_red('green') == -1\nTrue", 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

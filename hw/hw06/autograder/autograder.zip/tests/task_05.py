OK_FORMAT = True

test = {   'name': 'task_05',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> len(all_gains_red) == 10000\nTrue',
                                       'failure_message': '❌ all_gains_red should be an array with 10,000 items.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ all_gains_red is an array with 10,000 items.'},
                                   {'code': '>>> \n>>> (-80 <= all_gains_red).all() and (all_gains_red <= 60).all()\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

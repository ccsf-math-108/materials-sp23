OK_FORMAT = True

test = {   'name': 'task_17',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> coin_option in [1, 2, 3]\nTrue',
                                       'failure_message': '❌ 1, 2, or 3 should be assigned to coin_option.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ This is a possible value for coin_option'},
                                   {'code': '>>> \n>>> coin_option == 2\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

OK_FORMAT = True

test = {   'name': 'task_06',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> isinstance(loss_more_than_50, bool)\nTrue',
                                       'failure_message': '❌ loss_more_than_50 should be a bool value.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ loss_more_than_50 is a bool value.'},
                                   {'code': '>>> \n>>> loss_more_than_50 == True\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

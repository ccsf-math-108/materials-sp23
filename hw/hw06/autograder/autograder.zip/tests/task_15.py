OK_FORMAT = True

test = {   'name': 'task_15',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> toys_option in [1, 2, 3]\nTrue',
                                       'failure_message': '❌ 1, 2, or 3 should be assigned to toys_option.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ This is a possible value for toys_option.'},
                                   {'code': '>>> \n>>> toys_option == 1\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

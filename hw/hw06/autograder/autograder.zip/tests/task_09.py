OK_FORMAT = True

test = {   'name': 'task_09',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> len(all_gains_split) == 10000\nTrue',
                                       'failure_message': '❌ There should be 10,000 items in all_gains_split.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ There are 10,000 items in all_gains_split.'},
                                   {'code': '>>> \n>>> sum(gains.column(1) < -50) > sum(gains.column(0) < -50)\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

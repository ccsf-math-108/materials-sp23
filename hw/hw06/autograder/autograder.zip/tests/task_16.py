OK_FORMAT = True

test = {   'name': 'task_16',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> lottery_option in [1, 2, 3]\nTrue',
                                       'failure_message': '❌ 1, 2, or 3 should be assigned to lottery_option.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ This is a possible value for lottery_option.'},
                                   {'code': '>>> \n>>> lottery_option == 3\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
